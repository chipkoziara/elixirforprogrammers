import css from "../css/app.css"
import "phoenix_html"

import "./hangman_app"
